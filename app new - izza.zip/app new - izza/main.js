document.addEventListener('DOMContentLoaded', () => {
    const bookForm = document.getElementById('bookForm');
    const incompleteBookList = document.getElementById('incompleteBookList');
    const completeBookList = document.getElementById('completeBookList');

    loadBooks();

    bookForm.addEventListener('submit', (event) => {
        event.preventDefault();

        const title = document.getElementById('bookFormTitle').value;
        const author = document.getElementById('bookFormAuthor').value;
        const year = Number(document.getElementById('bookFormYear').value);
        const isComplete = document.getElementById('bookFormIsComplete').checked;

        const bookId = Date.now();
        const bookData = {
            id: bookId,
            title: title,
            author: author,
            year: year,
            isComplete: isComplete
        };

        addBookToStorage(bookData);

        bookForm.reset();
    });

    function loadBooks() {
        const books = JSON.parse(localStorage.getItem('books')) || [];
        books.forEach(book => {
            displayBook(book);
        });
    }

    function addBookToStorage(book) {
        const books = JSON.parse(localStorage.getItem('books')) || [];
        books.push(book);
        localStorage.setItem('books', JSON.stringify(books));
        displayBook(book);
    }

    function displayBook(book) {
        const bookContainer = document.createElement('div');
        bookContainer.setAttribute('data-bookid', book.id);
        bookContainer.setAttribute('data-testid', 'bookItem');

        bookContainer.innerHTML = `
            <h3 data-testid="bookItemTitle">${book.title}</h3>
            <p data-testid="bookItemAuthor">Penulis: ${book.author}</p>
            <p data-testid="bookItemYear">Tahun: ${book.year}</p>
            <div>
                <button data-testid="bookItemIsCompleteButton" onclick="toggleComplete(${book.id})">
                    ${book.isComplete ? 'Pindah ke Belum selesai dibaca' : 'Pindah ke Selesai dibaca'}
                </button>
                <button data-testid="bookItemDeleteButton" onclick="deleteBook(${book.id})">Hapus Buku</button>
                <button data-testid="bookItemEditButton" onclick="editBook(${book.id})">Edit Buku</button>
            </div>
        `;

        if (book.isComplete) {
            completeBookList.appendChild(bookContainer);
        } else {
            incompleteBookList.appendChild(bookContainer);
        }
    }
});
function deleteBook(id) {
    let books = JSON.parse(localStorage.getItem('books')) || [];
    books = books.filter(book => book.id !== id);
    localStorage.setItem('books', JSON.stringify(books));
    location.reload(); 
}

function editBook(id) {
    const books = JSON.parse(localStorage.getItem('books')) || [];
    const bookToEdit = books.find(book => book.id === id);

    if (bookToEdit) {
        document.getElementById('bookFormTitle').value = bookToEdit.title;
        document.getElementById('bookFormAuthor').value = bookToEdit.author;
        document.getElementById('bookFormYear').value = bookToEdit.year;
        document.getElementById('bookFormIsComplete').checked = bookToEdit.isComplete;
        deleteBook(id);
    }
}

function toggleComplete(id) {
    let books = JSON.parse(localStorage.getItem('books')) || [];
    const book = books.find(book => book.id === id);

    if (book) {
        book.isComplete = !book.isComplete;

        localStorage.setItem('books', JSON.stringify(books));

        location.reload();
    }
}
